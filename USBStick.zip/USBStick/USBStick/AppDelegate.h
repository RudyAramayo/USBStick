//
//  AppDelegate.h
//  USBStick
//
//  Created by Rudy Aramayo on 6/8/16.
//  Copyright © 2016 Verizon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

